# generated from colcon_core/shell/template/command_prefix.sh.em
