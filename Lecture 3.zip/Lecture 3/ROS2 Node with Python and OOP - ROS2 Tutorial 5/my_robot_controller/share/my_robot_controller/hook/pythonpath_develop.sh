# generated from colcon_core/shell/template/hook_prepend_value.sh.em

_colcon_prepend_unique_value PYTHONPATH "/home/abyan/ros2_ws/build/my_robot_controller"
