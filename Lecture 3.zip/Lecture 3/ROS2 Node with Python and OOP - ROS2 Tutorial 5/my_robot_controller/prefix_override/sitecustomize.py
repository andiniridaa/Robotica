import sys
sys.real_prefix = sys.prefix
sys.prefix = sys.exec_prefix = '/home/abyan/ros2_ws/install/my_robot_controller'
